SUPERLATIF QUESTION IMPORT — EXAMPLE PACKAGE v2.1

Isi paket:
- question-import-advanced-template.xlsx
- images/questions/SKD-TIU-001-stem.png
- images/explanations/SKD-TIU-001-explanation.png
- images/passages/PASS-TBI-001.png

Gunakan XLSX dan ZIP media ini pada halaman Question Import. Nama file pada
sheet Questions, Passages, dan Assets harus sama persis, termasuk kapital dan
subfolder. Kolom image_purpose memisahkan gambar informative dari decorative;
asset_role hanya menyatakan placement. Paket ini adalah contoh staging dan tidak
boleh langsung dipublikasikan sebagai tryout produksi tanpa validasi serta review
moderator.
